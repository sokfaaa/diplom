"""
Анализ и визуализация для главы 2 дипломной работы:
"Исследование методов борьбы с дисбалансом в многоклассовой классификации"

Разделы:
    2.3.3 — Синтетические данные (таблица характеристик)
    2.3.4 — Сравнение реальных и синтетических данных
    2.4   — Влияние алгоритмов балансировки
    2.5   — (статистические итоги для вывода)
"""

import warnings
warnings.filterwarnings("ignore")

import pandas as pd
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import matplotlib.gridspec as gridspec
from matplotlib.ticker import MaxNLocator
import seaborn as sns
from scipy import stats
from pathlib import Path

OUTPUT = Path("/mnt/user-data/outputs")
OUTPUT.mkdir(exist_ok=True)

# ─── Цветовая схема ────────────────────────────────────────────────────────
PALETTE = {
    "Baseline":           "#888888",
    "RandomOverSampler":  "#4C72B0",
    "SMOTE":              "#55A868",
    "BorderlineSMOTE":    "#C44E52",
    "SVMSMOTE":           "#8172B2",
    "ADASYN":             "#CCB974",
    "KMeansSMOTE":        "#64B5CD",
    "SMOTEENN":           "#E377C2",
    "SMOTETomek":         "#7F7F7F",
    "RandomUnderSampler": "#BCBD22",
    "TomekLinks":         "#17BECF",
    "ENN":                "#FF7F0E",
    "NCR":                "#D62728",
}

GROUP_COLORS = {
    "Oversampling": "#4C72B0",
    "Mixed":        "#55A868",
    "Undersampling":"#C44E52",
    "Baseline":     "#888888",
}

OVERSAMPLING  = ["RandomOverSampler", "SMOTE", "BorderlineSMOTE", "SVMSMOTE", "ADASYN", "KMeansSMOTE"]
MIXED         = ["SMOTEENN", "SMOTETomek"]
UNDERSAMPLING = ["RandomUnderSampler", "TomekLinks", "ENN", "NCR"]

def sampler_group(s):
    if s in OVERSAMPLING:  return "Oversampling"
    if s in MIXED:         return "Mixed"
    if s in UNDERSAMPLING: return "Undersampling"
    return "Baseline"

# ─── Загрузка данных ───────────────────────────────────────────────────────
meta_synth   = pd.read_csv("/mnt/user-data/uploads/metafeatures.csv")
meta_real    = pd.read_csv("/mnt/user-data/uploads/metafeatures_real.csv")
res_full_r   = pd.read_csv("/mnt/user-data/uploads/results_full_real.csv")
res_full_s   = pd.read_csv("/mnt/user-data/uploads/results_full_synth.csv")
res_summ_r   = pd.read_csv("/mnt/user-data/uploads/results_summary_real.csv")
res_summ_s   = pd.read_csv("/mnt/user-data/uploads/results_summary_synth.csv")
res_pivot_r  = pd.read_csv("/mnt/user-data/uploads/results_pivot_real.csv")
res_pivot_s  = pd.read_csv("/mnt/user-data/uploads/results_pivot_synth.csv")

res_full_r["group_type"] = res_full_r["sampler"].map(sampler_group)
res_full_s["group_type"] = res_full_s["sampler"].map(sampler_group)

print("Data loaded OK")

# ══════════════════════════════════════════════════════════════════════════
# 2.3.3 — ТАБЛИЦА характеристик синтетических датасетов (CSV + рисунок)
# ══════════════════════════════════════════════════════════════════════════

# Группируем по группам генерации (высокоуровневая классификация)
MAJOR_GROUPS = {
    "Случайные пары (rand_pair)": ["rand_pair"],
    "Случайные тройки (rand_triple)": ["rand_triple"],
    "Случайные мульти (rand_multi)": ["rand_multi"],
    "Случайные Moons": ["rand_moons"],
    "Случайные Circles": ["rand_circles"],
    "Случайные Swiss Roll": ["rand_swiss_roll"],
    "Случайные S-Curve": ["rand_s_curve"],
    "Случайные Gaussian Q.": ["rand_gaussian_quantiles"],
    "Экстремальный дисбаланс": ["extreme_imbalance", "extreme_low_dim_high_ir"],
    "Экстремально большие": ["extreme_large"],
    "Экстр. высокая размерность": ["extreme_high_dim", "extreme_high_dim_hybrid", "extreme_sparse", "extreme_combo"],
    "Экстр. шум": ["extreme_noise"],
    "Много классов": ["extreme_many_classes"],
    "Гибридные источники": [g for g in meta_synth["group"].unique()
                             if any(x in g for x in ["hybrid","triple","quad","all5"])],
    "Базовые геометрические": [g for g in meta_synth["group"].unique()
                                if g in ["circles","moons","swiss_roll","s_curve","gaussian",
                                         "classification","circles_gaussian","moons_gaussian",
                                         "gaussian_s_curve","gaussian_swiss_roll","circles_s_curve",
                                         "circles_swiss_roll","moons_s_curve","moons_swiss_roll",
                                         "moons_circles","s_curve_swiss_roll","gaussian_hybrid",
                                         "moons_hybrid","swiss_roll_hybrid","circles_hybrid",
                                         "s_curve_hybrid"]],
}

rows = []
for label, groups in MAJOR_GROUPS.items():
    sub = meta_synth[meta_synth["group"].isin(groups)]
    if len(sub) == 0:
        continue
    rows.append({
        "Группа":          label,
        "Датасетов":       len(sub),
        "Классов (мин–макс)": f"{int(sub['gen_n_classes'].min())}–{int(sub['gen_n_classes'].max())}",
        "IR (мин–макс)":   f"{sub['gen_imbalance_ratio'].min():.1f}–{sub['gen_imbalance_ratio'].max():.1f}",
        "Признаков (мин–макс)": f"{int(sub['gen_n_features'].min())}–{int(sub['gen_n_features'].max())}",
        "Объём train (мин–макс)": f"{int(sub.get('gen_n_samples_train', sub['gen_subsampled_to']).min())}–{int(sub.get('gen_n_samples_train', sub['gen_subsampled_to']).max())}",
    })
synth_table = pd.DataFrame(rows)
synth_table.to_csv(OUTPUT / "table_synth_groups.csv", index=False, encoding="utf-8-sig")
print("Saved: table_synth_groups.csv")

# ─── Рис 1: Распределение IR и n_classes в синтетических данных ───────────
fig, axes = plt.subplots(1, 2, figsize=(12, 4))

ax = axes[0]
ax.hist(meta_synth["IR"].clip(upper=100), bins=30, color="#4C72B0", edgecolor="white", alpha=0.85)
ax.set_xlabel("Коэффициент дисбаланса (IR)", fontsize=11)
ax.set_ylabel("Количество датасетов", fontsize=11)
ax.set_title("Распределение IR\n(синтетические данные, обрезано на 100)", fontsize=11)
ax.axvline(meta_synth["IR"].median(), color="red", linestyle="--", linewidth=1.5,
           label=f"Медиана = {meta_synth['IR'].median():.1f}")
ax.legend(fontsize=10)

ax = axes[1]
counts = meta_synth["gen_n_classes"].value_counts().sort_index()
ax.bar(counts.index.astype(str), counts.values, color="#55A868", edgecolor="white", alpha=0.85)
ax.set_xlabel("Количество классов", fontsize=11)
ax.set_ylabel("Количество датасетов", fontsize=11)
ax.set_title("Распределение числа классов\n(синтетические данные)", fontsize=11)

plt.tight_layout()
plt.savefig(OUTPUT / "fig1_synth_ir_nclasses.png", dpi=150, bbox_inches="tight")
plt.close()
print("Saved: fig1_synth_ir_nclasses.png")

# ══════════════════════════════════════════════════════════════════════════
# 2.3.4 — СРАВНЕНИЕ реальных и синтетических данных
# ══════════════════════════════════════════════════════════════════════════

compare_feats = {
    "IR": "Коэффициент дисбаланса (IR)",
    "nr_class": "Число классов",
    "nr_attr": "Число признаков",
    "nr_inst": "Размер датасета (обуч.)",
    "n1": "Доля граничных точек (N1)",
    "f1.mean": "Перекрытие классов (F1)",
    "lsc": "LSC (линейная разделимость)",
    "n2.mean": "N2 (кластеризация)",
}

# ─── Рис 2: KDE сравнение ключевых метафичей синтетик vs реальных ─────────
fig, axes = plt.subplots(2, 4, figsize=(16, 7))
axes = axes.flatten()

for i, (feat, label) in enumerate(compare_feats.items()):
    ax = axes[i]
    sv = meta_synth[feat].dropna()
    rv = meta_real[feat].dropna()

    # обрезаем выбросы для наглядности
    clip_pct = 99
    upper = max(np.percentile(sv, clip_pct), np.percentile(rv, clip_pct))

    sv_c = sv.clip(upper=upper)
    rv_c = rv.clip(upper=upper)

    sv_c.plot.kde(ax=ax, label="Синтетические", color="#4C72B0", linewidth=2)
    rv_c.plot.kde(ax=ax, label="Реальные", color="#C44E52", linewidth=2, linestyle="--")

    ks_stat, ks_p = stats.ks_2samp(sv, rv)
    ax.set_title(f"{label}\nKS={ks_stat:.2f}, p={'<0.001' if ks_p < 0.001 else f'{ks_p:.3f}'}", fontsize=9)
    ax.set_xlabel("")
    ax.set_ylabel("")
    ax.tick_params(labelsize=8)
    if i == 0:
        ax.legend(fontsize=8)

plt.suptitle("Сравнение распределений метапризнаков: синтетические vs реальные данные",
             fontsize=12, y=1.02)
plt.tight_layout()
plt.savefig(OUTPUT / "fig2_synth_vs_real_metafeatures.png", dpi=150, bbox_inches="tight")
plt.close()
print("Saved: fig2_synth_vs_real_metafeatures.png")

# ─── Рис 3: Scatter IR vs F1 improvement — synth vs real ─────────────────
def compute_improvement(df):
    baseline = df[df["sampler"] == "Baseline"][["dataset", "f1_macro"]].rename(columns={"f1_macro": "f1_base"})
    best = df.groupby("dataset")["f1_macro"].max().reset_index().rename(columns={"f1_macro": "f1_best"})
    merged = best.merge(baseline, on="dataset")
    merged["improvement"] = merged["f1_best"] - merged["f1_base"]
    return merged

impr_real  = compute_improvement(res_full_r)
impr_synth = compute_improvement(res_full_s)

# attach IR
ir_real  = res_full_r[["dataset", "IR"]].drop_duplicates()
ir_synth = res_full_s[["dataset", "IR"]].drop_duplicates()
impr_real  = impr_real.merge(ir_real, on="dataset")
impr_synth = impr_synth.merge(ir_synth, on="dataset")

fig, axes = plt.subplots(1, 2, figsize=(13, 5), sharey=True)
for ax, df, title, color in [
    (axes[0], impr_synth, "Синтетические данные (n=60)", "#4C72B0"),
    (axes[1], impr_real,  "Реальные данные (n=200)",     "#C44E52"),
]:
    clip = 100
    ax.scatter(df["IR"].clip(upper=clip), df["improvement"],
               alpha=0.55, s=35, color=color, edgecolors="white", linewidths=0.4)
    # trend
    x = df["IR"].clip(upper=clip)
    y = df["improvement"]
    z = np.polyfit(x, y, 1)
    p = np.poly1d(z)
    xs = np.linspace(x.min(), x.max(), 200)
    ax.plot(xs, p(xs), color="black", linewidth=1.5, linestyle="--", alpha=0.7)
    r, pv = stats.pearsonr(x, y)
    ax.set_title(f"{title}\nr={r:.2f}, p={'<0.001' if pv<0.001 else f'{pv:.3f}'}", fontsize=10)
    ax.set_xlabel("Коэффициент дисбаланса IR (обрезано до 100)", fontsize=10)
    ax.axhline(0, color="grey", linewidth=0.8, linestyle=":")

axes[0].set_ylabel("Улучшение F1-macro над Baseline", fontsize=10)
plt.suptitle("Улучшение балансировки в зависимости от IR", fontsize=12)
plt.tight_layout()
plt.savefig(OUTPUT / "fig3_ir_vs_improvement.png", dpi=150, bbox_inches="tight")
plt.close()
print("Saved: fig3_ir_vs_improvement.png")

# ─── Рис 4: Результаты балансировки на синтетических vs реальных ──────────
fig, axes = plt.subplots(1, 2, figsize=(14, 5))
for ax, df, title in [
    (axes[0], res_summ_s, "Синтетические данные"),
    (axes[1], res_summ_r, "Реальные данные"),
]:
    order = df.sort_values("f1_macro_mean", ascending=False)["sampler"]
    colors = [PALETTE.get(s, "#aaaaaa") for s in order]
    y_pos = range(len(order))
    ax.barh(list(y_pos), df.set_index("sampler").loc[order, "f1_macro_mean"].values,
            color=colors, alpha=0.85, edgecolor="white")
    ax.set_yticks(list(y_pos))
    ax.set_yticklabels(order, fontsize=9)
    ax.set_xlabel("Среднее F1-macro", fontsize=10)
    ax.set_title(title, fontsize=11)
    ax.axvline(df.loc[df["sampler"]=="Baseline","f1_macro_mean"].values[0],
               color="black", linewidth=1.2, linestyle="--", alpha=0.6, label="Baseline")
    ax.legend(fontsize=9)

plt.suptitle("Среднее F1-macro по алгоритмам балансировки", fontsize=12)
plt.tight_layout()
plt.savefig(OUTPUT / "fig4_f1_comparison_all_samplers.png", dpi=150, bbox_inches="tight")
plt.close()
print("Saved: fig4_f1_comparison_all_samplers.png")

# ══════════════════════════════════════════════════════════════════════════
# 2.4 — ВЛИЯНИЕ АЛГОРИТМОВ БАЛАНСИРОВКИ
# ══════════════════════════════════════════════════════════════════════════

# ─── Рис 5: Boxplot F1 по группам методов (реальные данные) ───────────────
fig, ax = plt.subplots(figsize=(12, 5))
order_groups = ["Baseline", "Oversampling", "Mixed", "Undersampling"]
data_groups  = [res_full_r[res_full_r["group_type"] == g]["f1_macro"].dropna() for g in order_groups]
bp = ax.boxplot(data_groups, labels=order_groups, patch_artist=True, medianprops={"linewidth":2,"color":"black"})
for patch, grp in zip(bp["boxes"], order_groups):
    patch.set_facecolor(GROUP_COLORS[grp])
    patch.set_alpha(0.75)
ax.set_ylabel("F1-macro", fontsize=11)
ax.set_xlabel("Группа методов", fontsize=11)
ax.set_title("Распределение F1-macro по группам методов балансировки (реальные данные)", fontsize=11)
ax.yaxis.grid(True, linestyle="--", alpha=0.5)
plt.tight_layout()
plt.savefig(OUTPUT / "fig5_boxplot_groups_real.png", dpi=150, bbox_inches="tight")
plt.close()
print("Saved: fig5_boxplot_groups_real.png")

# ─── Рис 6: Violin — каждый сэмплер на реальных данных ───────────────────
sampler_order = (["Baseline"] + OVERSAMPLING + MIXED + UNDERSAMPLING)
fig, ax = plt.subplots(figsize=(16, 6))
plot_data = [res_full_r[res_full_r["sampler"] == s]["f1_macro"].dropna() for s in sampler_order]
parts = ax.violinplot(plot_data, positions=range(len(sampler_order)), showmedians=True, showextrema=False)
for i, (pc, s) in enumerate(zip(parts["bodies"], sampler_order)):
    pc.set_facecolor(PALETTE.get(s, "#aaaaaa"))
    pc.set_alpha(0.7)
parts["cmedians"].set_color("black")
parts["cmedians"].set_linewidth(2)
ax.set_xticks(range(len(sampler_order)))
ax.set_xticklabels(sampler_order, rotation=35, ha="right", fontsize=9)
ax.set_ylabel("F1-macro", fontsize=11)
ax.set_title("Violin-plot F1-macro по алгоритмам балансировки (реальные данные, n=200)", fontsize=11)
ax.yaxis.grid(True, linestyle="--", alpha=0.4)
# add group separators
for x_sep in [0.5, 6.5, 8.5]:
    ax.axvline(x_sep, color="grey", linewidth=0.8, linestyle=":")
ax.text(3.5,  ax.get_ylim()[0]-0.03, "Oversampling", ha="center", fontsize=8, color="#4C72B0", weight="bold")
ax.text(7.5,  ax.get_ylim()[0]-0.03, "Mixed",         ha="center", fontsize=8, color="#55A868", weight="bold")
ax.text(10.5, ax.get_ylim()[0]-0.03, "Undersampling", ha="center", fontsize=8, color="#C44E52", weight="bold")
plt.tight_layout()
plt.savefig(OUTPUT / "fig6_violin_all_samplers_real.png", dpi=150, bbox_inches="tight")
plt.close()
print("Saved: fig6_violin_all_samplers_real.png")

# ─── Рис 7: Heatmap — медиана F1 по (sampler x n_classes) ────────────────
fig, axes = plt.subplots(1, 2, figsize=(16, 5))
for ax, df, title in [
    (axes[0], res_full_r, "Реальные данные"),
    (axes[1], res_full_s, "Синтетические данные"),
]:
    pivot = df.pivot_table(index="sampler", columns="n_classes", values="f1_macro", aggfunc="median")
    pivot = pivot.reindex(sampler_order)
    sns.heatmap(pivot, ax=ax, cmap="RdYlGn", annot=True, fmt=".2f", linewidths=0.4,
                cbar_kws={"label": "Медиана F1-macro"}, annot_kws={"size": 8})
    ax.set_title(f"Медиана F1-macro: алгоритм × число классов\n({title})", fontsize=10)
    ax.set_xlabel("Число классов", fontsize=10)
    ax.set_ylabel("Алгоритм", fontsize=10)
    ax.tick_params(axis="y", labelsize=8)

plt.tight_layout()
plt.savefig(OUTPUT / "fig7_heatmap_sampler_nclasses.png", dpi=150, bbox_inches="tight")
plt.close()
print("Saved: fig7_heatmap_sampler_nclasses.png")

# ─── Рис 8: F1-macro vs IR — по группам методов (реальные) ───────────────
fig, axes = plt.subplots(1, 2, figsize=(14, 5))
for ax, df, title in [
    (axes[0], res_full_r, "Реальные данные"),
    (axes[1], res_full_s, "Синтетические данные"),
]:
    for grp in ["Baseline", "Oversampling", "Mixed", "Undersampling"]:
        sub = df[df["group_type"] == grp]
        # bin IR
        sub = sub.copy()
        sub["IR_bin"] = pd.qcut(sub["IR"].clip(upper=50), q=6, duplicates="drop")
        grp_means = sub.groupby("IR_bin")["f1_macro"].mean().reset_index()
        grp_means["IR_mid"] = grp_means["IR_bin"].apply(lambda x: x.mid)
        ax.plot(grp_means["IR_mid"], grp_means["f1_macro"],
                label=grp, color=GROUP_COLORS[grp], linewidth=2, marker="o", markersize=5)
    ax.set_xlabel("IR (обрезан до 50)", fontsize=10)
    ax.set_ylabel("Среднее F1-macro", fontsize=10)
    ax.set_title(title, fontsize=10)
    ax.legend(fontsize=9)
    ax.yaxis.grid(True, linestyle="--", alpha=0.4)

plt.suptitle("F1-macro в зависимости от IR по группам методов балансировки", fontsize=12)
plt.tight_layout()
plt.savefig(OUTPUT / "fig8_f1_vs_ir_by_group.png", dpi=150, bbox_inches="tight")
plt.close()
print("Saved: fig8_f1_vs_ir_by_group.png")

# ══════════════════════════════════════════════════════════════════════════
# 2.4 — АНАЛИЗ КАСТОМНЫХ МЕТАФИЧ
# ══════════════════════════════════════════════════════════════════════════

# Объединяем metafeatures_real с результатами (реальные данные)
real_pivot_impr = compute_improvement(res_full_r)
meta_r = meta_real.copy()
meta_r.index = meta_r["dataset_name"]

# Объединяем по dataset
real_full_meta = res_full_r.merge(meta_real, left_on="dataset", right_on="dataset_name", how="left")
improvement_df = real_pivot_impr.merge(meta_real, left_on="dataset", right_on="dataset_name", how="inner")

custom_feats = {
    "IR":                   "Коэффициент дисбаланса (IR)",
    "IR_variance":          "Дисперсия IR по классам",
    "pIR_cv":               "CV коэффициента дисбаланса (pIR_cv)",
    "macro_IR":             "Macro-IR",
    "n_minority_classes":   "Число миноритарных классов",
    "class_imbalance_skew": "Асимметрия дисбаланса",
    "CV":                   "Коэффициент вариации (CV) размеров классов",
    "HDB":                  "HDB (кластеризуемость)",
    "HDB_mean_f1":          "Среднее F1 внутри кластеров (HDB_mean_f1)",
    "minority_isolation":   "Изоляция миноритарного класса",
    "minority_nn_ratio":    "Доля ближайших соседей (minority_nn_ratio)",
    "minority_frac":        "Доля миноритарного класса",
    "overlap_ratio":        "Overlap ratio",
    "boundary_density":     "Плотность границы (boundary_density)",
    "inter_intra_ratio":    "Inter-intra distance ratio",
}

# ─── Рис 9: Корреляция кастомных метафичей с улучшением над Baseline ──────
corr_rows = []
for feat, label in custom_feats.items():
    if feat not in improvement_df.columns:
        continue
    tmp = improvement_df[["improvement", feat]].dropna()
    if len(tmp) < 10:
        continue
    r, p = stats.pearsonr(tmp["improvement"], tmp[feat])
    corr_rows.append({"feature": feat, "label": label, "r": r, "p": p, "n": len(tmp)})

corr_df = pd.DataFrame(corr_rows).sort_values("r")
corr_df["sig"] = corr_df["p"].apply(lambda p: "***" if p < 0.001 else ("**" if p < 0.01 else ("*" if p < 0.05 else "")))
corr_df.to_csv(OUTPUT / "table_custom_feature_correlations.csv", index=False, encoding="utf-8-sig")

fig, ax = plt.subplots(figsize=(10, 7))
colors = ["#C44E52" if r < 0 else "#4C72B0" for r in corr_df["r"]]
bars = ax.barh(corr_df["label"], corr_df["r"], color=colors, alpha=0.8, edgecolor="white")
for i, (r, sig) in enumerate(zip(corr_df["r"], corr_df["sig"])):
    ax.text(r + (0.005 if r >= 0 else -0.005), i, sig,
            va="center", ha="left" if r >= 0 else "right", fontsize=10, fontweight="bold")
ax.axvline(0, color="black", linewidth=0.8)
ax.set_xlabel("Корреляция Пирсона с улучшением F1-macro", fontsize=10)
ax.set_title("Корреляция кастомных метапризнаков\nс улучшением балансировки над Baseline (реальные данные)", fontsize=11)
ax.tick_params(axis="y", labelsize=9)
ax.xaxis.grid(True, linestyle="--", alpha=0.4)
plt.tight_layout()
plt.savefig(OUTPUT / "fig9_custom_feature_correlations.png", dpi=150, bbox_inches="tight")
plt.close()
print("Saved: fig9_custom_feature_correlations.png")

# ─── Рис 10: Scatter — IR_variance, pIR_cv, CV vs improvement ─────────────
key_feats = ["IR_variance", "pIR_cv", "CV", "n_minority_classes"]
key_labels = ["Дисперсия IR по классам", "pIR_cv", "CV размеров классов", "Число миноритарных классов"]

fig, axes = plt.subplots(1, 4, figsize=(18, 4))
for ax, feat, label in zip(axes, key_feats, key_labels):
    if feat not in improvement_df.columns:
        ax.set_visible(False)
        continue
    tmp = improvement_df[["improvement", feat]].dropna()
    clip = np.percentile(tmp[feat], 98)
    tmp_c = tmp[tmp[feat] <= clip]
    ax.scatter(tmp_c[feat], tmp_c["improvement"], alpha=0.45, s=25,
               color="#4C72B0", edgecolors="white", linewidths=0.3)
    z = np.polyfit(tmp_c[feat], tmp_c["improvement"], 1)
    xs = np.linspace(tmp_c[feat].min(), tmp_c[feat].max(), 200)
    ax.plot(xs, np.poly1d(z)(xs), color="#C44E52", linewidth=2, linestyle="--")
    r, p = stats.pearsonr(tmp_c[feat], tmp_c["improvement"])
    ax.set_xlabel(label, fontsize=9)
    ax.set_title(f"r={r:.2f}, p={'<0.001' if p<0.001 else f'{p:.3f}'}", fontsize=9)
    ax.axhline(0, color="grey", linewidth=0.7, linestyle=":")
    ax.yaxis.grid(True, linestyle="--", alpha=0.4)

axes[0].set_ylabel("Улучшение F1-macro", fontsize=10)
plt.suptitle("Кастомные метапризнаки vs. улучшение балансировки (реальные данные)", fontsize=11)
plt.tight_layout()
plt.savefig(OUTPUT / "fig10_custom_feats_vs_improvement.png", dpi=150, bbox_inches="tight")
plt.close()
print("Saved: fig10_custom_feats_vs_improvement.png")

# ─── Рис 11: Гетерогенность — dispersion кастомных метафич ───────────────
disp_feats = ["IR_variance", "pIR_cv", "CV", "n_minority_classes",
              "class_imbalance_skew", "minority_isolation", "HDB"]

fig, axes = plt.subplots(1, len(disp_feats), figsize=(18, 4))
for ax, feat in zip(axes, disp_feats):
    if feat not in meta_real.columns:
        ax.set_visible(False)
        continue
    vals = meta_real[feat].dropna()
    clip = np.percentile(vals, 97)
    vals_c = vals[vals <= clip]
    ax.hist(vals_c, bins=25, color="#55A868", edgecolor="white", alpha=0.85)
    cv_val = vals_c.std() / (vals_c.mean() + 1e-9)
    ax.set_title(f"{feat}\n(CV={cv_val:.2f})", fontsize=8)
    ax.tick_params(labelsize=7)

plt.suptitle("Распределение кастомных метапризнаков на реальных данных\n(CV = std/mean — показатель гетерогенности)", fontsize=11)
plt.tight_layout()
plt.savefig(OUTPUT / "fig11_custom_feats_heterogeneity.png", dpi=150, bbox_inches="tight")
plt.close()
print("Saved: fig11_custom_feats_heterogeneity.png")

# ─── Рис 12: Лучший алгоритм в зависимости от групп IR ───────────────────
bins = [0, 2, 5, 10, 30, 1e9]
labels_ir = ["1–2", "2–5", "5–10", "10–30", ">30"]
res_full_r2 = res_full_r.copy()
res_full_r2["IR_group"] = pd.cut(res_full_r2["IR"], bins=bins, labels=labels_ir, right=True)
best_per_dataset = res_full_r2.loc[res_full_r2.groupby("dataset")["f1_macro"].idxmax()][["dataset", "sampler", "IR_group"]].copy()
best_per_dataset["group_type"] = best_per_dataset["sampler"].map(sampler_group)
heat_data = best_per_dataset.groupby(["IR_group", "group_type"]).size().unstack(fill_value=0)
heat_data = heat_data.reindex(labels_ir)
for col in ["Baseline", "Oversampling", "Mixed", "Undersampling"]:
    if col not in heat_data.columns:
        heat_data[col] = 0
heat_data = heat_data[["Baseline", "Oversampling", "Mixed", "Undersampling"]]

fig, ax = plt.subplots(figsize=(9, 4))
heat_data_pct = heat_data.div(heat_data.sum(axis=1), axis=0) * 100
sns.heatmap(heat_data_pct, ax=ax, cmap="YlOrRd", annot=True, fmt=".0f",
            linewidths=0.5, cbar_kws={"label": "% датасетов"})
ax.set_xlabel("Группа методов", fontsize=10)
ax.set_ylabel("Диапазон IR", fontsize=10)
ax.set_title("Доля датасетов (%), на которых лучший алгоритм принадлежит группе,\nв зависимости от IR (реальные данные)", fontsize=10)
plt.tight_layout()
plt.savefig(OUTPUT / "fig12_best_group_by_ir.png", dpi=150, bbox_inches="tight")
plt.close()
print("Saved: fig12_best_group_by_ir.png")

# ─── Итоговая сводная таблица ──────────────────────────────────────────────
summary_rows = []
for s in sampler_order:
    for (df, label) in [(res_full_r, "Real"), (res_full_s, "Synth")]:
        sub = df[df["sampler"] == s]
        summary_rows.append({
            "Алгоритм": s,
            "Набор данных": label,
            "Среднее F1": round(sub["f1_macro"].mean(), 4),
            "Медиана F1": round(sub["f1_macro"].median(), 4),
            "Std F1": round(sub["f1_macro"].std(), 4),
            "Ср. Balanced Acc.": round(sub["balanced_accuracy"].mean(), 4),
            "Группа": sampler_group(s),
        })
pd.DataFrame(summary_rows).to_csv(OUTPUT / "table_sampler_summary.csv", index=False, encoding="utf-8-sig")
print("Saved: table_sampler_summary.csv")

print("\n✅ Все графики и таблицы сохранены в /mnt/user-data/outputs/")
